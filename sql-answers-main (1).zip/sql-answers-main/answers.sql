-- question 98 --

CREATE TABLE transactions (
    dt VARCHAR(19),
    customer VARCHAR(64),
    debit DECIMAL(5,2),
    credit DECIMAL(5,2)
);

INSERT INTO transactions (dt, customer, debit, credit) VALUES
('2021-11-30 12:48:22', 'Arney Cuff', 6.43, 16.12),
('2021-12-25 19:00:46', 'Arney Cuff', 97.78, 12.53),
('2021-11-27 21:34:24', 'Donaugh Furneaux', 89.71, 85.04),
('2021-11-15 07:31:37', 'Ferrell Brunn', 63.58, 28.58),
('2021-11-25 15:30:56', 'Gibbie Jurisic', 25.81, 13.75),
('2021-11-21 00:09:50', 'Harley Lyddiard', 57.49, 7.11),
('2021-12-01 07:37:42', 'Harley Lyddiard', 48.33, 82.35),
('2021-12-02 13:08:52', 'Harley Lyddiard', 12.13, 63.81),
('2021-11-24 03:51:13', 'Kippy Jelly', 50.34, 12.91),
('2021-12-04 10:11:40', 'Latrina Jackman', 10.73, 39.51),
('2021-12-02 13:02:50', 'Latrina Jackman', 5.35, 96.74),
('2022-10-17 13:44:00', 'Latrina Jackman', 54.99, 92.73),
('2012-10-30 14:43:00', 'Maribel Braim', 57.02, 9.61),
('2012-10-20 09:57:00', 'Orrin Curley', 65.44, 51.31),
('2012-10-14 19:57:25', 'Orrin Curley', 84.14, 96.44),
('2010-10-09 20:28:21', 'Rasla Venny', 80.33, 20.69);

Select customer , round(Sum(debit)-sum(credit),2)
from transactions
where dt LIKE '%-12%'
group by customer
order by customer


-- question 97

CREATE TABLE EMPLOYEE (
    NAME VARCHAR(50),
    PHONE VARCHAR(15),
    AGE INT
);

INSERT INTO EMPLOYEE (NAME, PHONE, AGE) VALUES
('Sam', '1000040000', 30),
('Alex', '1000020000', 60),
('Alex', '1000020012', 65),
('Sam', '1000040000', 30),
('Chris', '1000012000', 34),
('Chris', '1000012000', 34);

SELECT name
FROM employee
GROUP BY name,phone,age
HAVING COUNT(*)>1;


-- question 96
CREATE TABLE STUDENT (
    ID INT PRIMARY KEY,
    AGE INT,
    SCORE INT
);

INSERT INTO STUDENT (ID, AGE, SCORE) VALUES
(1, 19, 91),
(2, 20, 90),
(3, 20, 87),
(4, 21, 72),
(5, 19, 98),
(6, 20, 50);

select id,score
from student
order by score desc
limit 1
offset 4;


-- question 95

CREATE TABLE STUDENTS (
    STUDENT_ID INT PRIMARY KEY,
    STUDENT_NAME VARCHAR(50),
    STUDENT_AGE INT
);

CREATE TABLE MAJORS (
    MAJOR_ID INT PRIMARY KEY,
    MAJOR_NAME VARCHAR(50)
);

CREATE TABLE REGISTER (
    STUDENT_ID INT,
    MAJOR_ID INT,
    FOREIGN KEY (STUDENT_ID) REFERENCES STUDENTS(STUDENT_ID),
    FOREIGN KEY (MAJOR_ID) REFERENCES MAJORS(MAJOR_ID)
);

-- Insert into STUDENTS
INSERT INTO STUDENTS (STUDENT_ID, STUDENT_NAME, STUDENT_AGE) VALUES
(1, 'John', 20),
(2, 'Masie', 21),
(3, 'Harry', 21);

-- Insert into MAJORS
INSERT INTO MAJORS (MAJOR_ID, MAJOR_NAME) VALUES
(1000, 'Computer Science'),
(2000, 'Biology'),
(3000, 'Physics');

-- Insert into REGISTER
INSERT INTO REGISTER (STUDENT_ID, MAJOR_ID) VALUES
(2, 1000),
(3, 3000),
(1, 2000);

-- A university maintains data on students and their majors in three tables: STUDENTS, MAJORS, and REGISTER. The university needs a list of STUDENT_NAME and MAJOR_NAME. Sort the list by STUDENT_ID and return the first 20 records.
Select s.student_name,m.major_name
from students s
join register r on s.student_id=r.student_id
join majors m on m.major_id=r.major_id
order by s.student_id


-- question 94

-- A university maintains data on professors and departments in two tables: PROFESSOR and DEPARTMENT. Write a query to print the NAME and SALARY for each 
-- professor who satisfies the following two requirements:
-- The professor does not work in the Arts and Humanities department.
-- The professor's salary is greater than the smallest salary of any professor in the Arts and Humanities department.
-- The name must be printed before the salary, but row order does not matter.

CREATE TABLE DEPARTMENT (
    ID INT PRIMARY KEY,
    NAME VARCHAR(100)
);

CREATE TABLE PROFESSOR (
    ID INT PRIMARY KEY,
    NAME VARCHAR(100),
    DEPARTMENT_ID INT,
    SALARY INT,
    FOREIGN KEY (DEPARTMENT_ID) REFERENCES DEPARTMENT(ID)
);

INSERT INTO DEPARTMENT (ID, NAME) VALUES
(3, 'Biological Sciences'),
(5, 'Technology'),
(6, 'Humanities & Social Sciences'),
(2, 'Clinical Medicine'),
(4, 'Arts and Humanities'),
(1, 'Physical Sciences');

INSERT INTO PROFESSOR (ID, NAME, DEPARTMENT_ID, SALARY) VALUES
(1, 'Shauna Rivera', 1, 22606),
(8, 'Ruth Price', 3, 9287),
(9, 'Julie Gonzalez', 4, 18870),
(2, 'Craig Elliott', 5, 27524),
(10, 'Scott Butler', 1, 26200),
(3, 'Nancy Russell', 2, 7076);

SELECT p.name,p.salary
FROM professor p
JOIN department d ON p.department_id=d.id
WHERE d.name not like 'Arts and Humanities' AND salary>(
SELECT min(salary) 
FROM professor p 
JOIN department d ON p.department_id=d.id  
WHERE d.name='Arts and Humanities' 
) ;

SELECT min(salary) 
FROM professor p 
JOIN department d ON p.department_id=d.id  
WHERE d.name='Arts and Humanities' 

-- .......................................................................................................................

-- question 93

-- Write a query to return a list of professor names and their associated courses. The results can be in any order but must not contain duplicate rows.

CREATE TABLE PROFESSORS (
    ID INT PRIMARY KEY,
    NAME VARCHAR(100),
    DEPARTMENT_ID INT,
    SALARY INT,
    FOREIGN KEY (DEPARTMENT_ID) REFERENCES DEPARTMENT(ID)
);

CREATE TABLE COURSE (
    ID INT PRIMARY KEY,
    NAME VARCHAR(100),
    DEPARTMENT_ID INT,
    CREDITS INT,
    FOREIGN KEY (DEPARTMENT_ID) REFERENCES DEPARTMENT(ID)
);

CREATE TABLE SCHEDULE (
    PROFESSOR_ID INT,
    COURSE_ID INT,
    SEMESTER INT,
    YEAR INT,
    FOREIGN KEY (PROFESSOR_ID) REFERENCES PROFESSOR(ID),
    FOREIGN KEY (COURSE_ID) REFERENCES COURSE(ID)
);

CREATE TABLE DEPARTMENTS (
    ID INT PRIMARY KEY,
    NAME VARCHAR(100)
);

INSERT INTO DEPARTMENTS (ID, NAME) VALUES
(3, 'Biological Sciences'),
(5, 'Technology'),
(6, 'Humanities & Social Sciences'),
(2, 'Clinical Medicine'),
(4, 'Arts and Humanities'),
(1, 'Physical Sciences');


INSERT INTO PROFESSORS (ID, NAME, DEPARTMENT_ID, SALARY) VALUES
(1, 'Alex Burton', 5, 7340),
(8, 'Jordan Diaz', 1, 17221),
(9, 'Drew Hicks', 5, 16613),
(2, 'Tyler Matthews', 2, 14521),
(10, 'Blake Foster', 4, 28526),
(3, 'Spencer Peters', 1, 10487),
(4, 'Ellis Marshall', 3, 6353),
(7, 'Morgan Lee', 2, 25796),
(5, 'Riley Peterson', 1, 35678),
(6, 'Peyton Fields', 5, 26648);



INSERT INTO COURSE (ID, NAME, DEPARTMENT_ID, CREDITS) VALUES
(9, 'Clinical Biochemistry', 2, 3),
(4, 'Astronomy', 1, 6),
(10, 'Clinical Neuroscience', 2, 5),
(1, 'Pure Mathematics and Mathematical Statistics', 1, 3),
(6, 'Geography', 1, 7),
(8, 'Chemistry', 1, 1),
(5, 'Physics', 1, 8),
(3, 'Earth Science', 1, 7),
(7, 'Materials Science and Metallurgy', 1, 5),
(2,' Applied Mathematics and Theoretical Physics',1,5);  -- Credits not provided

INSERT INTO SCHEDULE (PROFESSOR_ID, COURSE_ID, SEMESTER, YEAR) VALUES
(5, 3, 6, 2012),
(7, 3, 1, 2013),
(5, 7, 6, 2010),
(2, 10, 2, 2004),
(5, 1, 1, 2011),
(2, 9, 4, 2005),
(7, 10, 6, 2009),
(5, 6, 4, 2007),
(7, 9, 1, 2014),
(9, 9, 5, 2011);


-- ........................................................................

-- QUESTION 91

-- An organization maintains employment data in three tables: EMPLOYEE, COMPANY, and SALARY. Write a query to print the names of every company where 
-- the average salary is greater than 40000. Each distinct row of results in the output must contain the name of a company whose average employee salary is > 
-- 40,000 in the COMPANY.NAME format

CREATE TABLE EMPLOYEES (
    ID INT PRIMARY KEY,
    NAME VARCHAR(100)
);

CREATE TABLE COMPANY (
    ID INT PRIMARY KEY,
    NAME VARCHAR(100)
);

CREATE TABLE SALARY (
    EMPLOYEE_ID INT,
    COMPANY_ID INT,
    SALARY INT,
    FOREIGN KEY (EMPLOYEE_ID) REFERENCES EMPLOYEES(ID),
    FOREIGN KEY (COMPANY_ID) REFERENCES COMPANY(ID)
);

INSERT INTO EMPLOYEES (ID, NAME) VALUES
(1, 'Frances White'),
(2, 'Carolyn Bradley'),
(3, 'Annie Fernandez'),
(4, 'Ruth Hanson'),
(5, 'Paula Fuller'),
(6, 'Bonnie Johnston'),
(7, 'Ruth Gutierrez'),
(8, 'Ernest Thomas'),
(9, 'Joe Garza'),
(10, 'Anne Harris');

INSERT INTO COMPANY (ID, NAME) VALUES
(1, 'PeopleSoft Inc'),
(2, 'Baker Hughes Incorporated'),
(3, 'MDU Resources Group Inc.'),
(4, 'DST Systems, Inc.'),
(5, 'Williams Companies Inc'),
(6, 'Fisher Scientific International Inc.'),
(7, 'Emcor Group Inc.'),
(8, 'Genuine Parts Company'),
(9, 'MPS Group Inc.'),
(10, 'Novellus Systems Inc');

INSERT INTO SALARY (EMPLOYEE_ID, COMPANY_ID, SALARY) VALUES
(2, 4, 27779),
(2, 9, 36330),
(3, 9, 71466),
(3, 10, 22804),
(5, 5, 49892),
(6, 4, 31493),
(6, 10, 26888),
(7, 3, 87118),
(7, 7, 70767),
(7, 9, 39929);


SELECT C.NAME
FROM COMPANY C
JOIN SALARY S ON C.ID=S.COMPANY_ID
JOIN EMPLOYEES E ON E.ID=S.EMPLOYEE_ID
GROUP BY C.NAME
HAVING AVG(S.SALARY)>40000;




-- question 84

-- A restaurant is visited by various customers during a day. At the same time, the restaurant is advertising to increase customer revenue. Write an SQL query to 
-- compute the moving average of how much customers spent over a window of 7 days (current day and 6 days before) to analyze their business growth. The 
-- output should contain three columns {visited_on, amount, avg_amount(avg over 7 days)}


CREATE TABLE CUSTOMERS (
    id INTEGER PRIMARY KEY,
    name VARCHAR(100),
    phone VARCHAR(20),
    visited_on DATE,
    amount INTEGER
);

INSERT INTO CUSTOMERS (id, name, phone, visited_on, amount) VALUES
(1, 'Julia', '1234567890', '2015-05-01', 100),
(2, 'Samantha', '1234567890', '2015-05-02', 200),
(3, 'Julia-Samantha', '1234567890', '2015-05-03', 300);
drop table customers

SELECT
    c1.visited_on,
    c1.amount AS amount,
    ROUND(AVG(c2.amount), 4) AS avg_amount
FROM CUSTOMERS c1
JOIN CUSTOMERS c2 ON c2.visited_on BETWEEN c1.visited_on - INTERVAL '6 days' AND c1.visited_on
GROUP BY c1.visited_on,c1.amount

-- question 83
-- A parent keeps track of the activities of a child and their friends in two tables: FRIENDS and ACTIVITIES. Write a query to print the names of all the activities 
-- with neither the maximum nor minimum number of participants.

CREATE TABLE FRIENDS (
    ID INTEGER PRIMARY KEY,
    NAME VARCHAR(100),
    ACTIVITY VARCHAR(100)
);

CREATE TABLE ACTIVITIES (
    ID INTEGER PRIMARY KEY,
    NAME VARCHAR(100)
);

INSERT INTO FRIENDS (ID, NAME, ACTIVITY) VALUES
(1, 'James Smith', 'Horse Riding'),
(2, 'Eric Jenkins', 'Eating'),
(3, 'Sean Cox', 'Eating'),
(4, 'Eric Schmidt', 'Horse Riding'),
(5, 'Chris Evans', 'Eating'),
(6, 'Jessica Breeds', 'Playing');

INSERT INTO ACTIVITIES (ID, NAME) VALUES
(1, 'Horse Riding'),
(2, 'Eating'),
(3, 'Playing');

WITH activity_counts AS (
    SELECT ACTIVITY, COUNT(*) AS participant_count
    FROM FRIENDS
    GROUP BY ACTIVITY
),
min_max AS (
    SELECT MIN(participant_count) AS min_count,
           MAX(participant_count) AS max_count
    FROM activity_counts
)
SELECT ACTIVITY
FROM activity_counts, min_max
WHERE participant_count NOT IN (min_count, max_count);


SELECT ACTIVITY
FROM FRIENDS
GROUP BY ACTIVITY
HAVING COUNT(*) NOT IN (
    SELECT COUNT(*) 
    FROM FRIENDS 
    GROUP BY ACTIVITY
    ORDER BY COUNT(*) 
    LIMIT 1
)
AND COUNT(*) NOT IN (
    SELECT COUNT(*) 
    FROM FRIENDS 
    GROUP BY ACTIVITY
    ORDER BY COUNT(*) DESC
    LIMIT 1
);

-- question 39

-- A company's finance department wishes to understand the total cash flow expected from bond investments for each bondholder. Create a query to calculate 
-- this based on coupon payments of the bonds each bondholder possesses.
-- The result should have the following columns: name | total_cash_flow. 
-- name - name of the bondholder
-- total_cash_flow - total expected cash flow from all bonds the bondholder possesses with 2 places after the decimal, e.g., 10 shows as 10.00.
-- The result should be sorted in descending order by total_cash_flow.


-- Create bondholders table
CREATE TABLE bondholders (
    id INT PRIMARY KEY,
    name VARCHAR(255)
);

-- Create bonds table
CREATE TABLE bonds (
    id INT PRIMARY KEY,
    name VARCHAR(255),
    annual_coupon DECIMAL(5,2),
    coupons_remaining INT
);

-- Create bondholders_bonds table
CREATE TABLE bondholders_bonds (
    bondholder_id INT,
    bond_id INT,
    FOREIGN KEY (bondholder_id) REFERENCES bondholders(id),
    FOREIGN KEY (bond_id) REFERENCES bonds(id)
);

-- Insert data into bondholders
INSERT INTO bondholders (id, name) VALUES
(1, 'Alex Smith'),
(2, 'Taylor Johnson'),
(3, 'Jordan Davis');

-- Insert data into bonds
INSERT INTO bonds (id, name, annual_coupon, coupons_remaining) VALUES
(1, 'Golden Bonds', 150.00, 4),
(2, 'Silver Lining', 200.00, 2),
(3, 'Diamond Trust', 100.00, 4),
(4, 'Emerald Wealth', 350.00, 5),
(5, 'Ruby Returns', 150.00, 8),
(6, 'Sapphire Security', 450.00, 5),
(7, 'Amber Assurance', 100.00, 8),
(8, 'Topaz Treasury', 100.00, 2),
(9, 'Opal Opportunities', 150.00, 5),
(10, 'Pearl Prosperity', 450.00, 5),
(11, 'Platinum Promise', 450.00, 9),
(12, 'Jade Investments', 350.00, 1),
(13, 'Garnet Growth', 150.00, 4),
(14, 'Onyx Returns', 350.00, 2),
(15, 'Quartz Capital', 100.00, 2),
(16, 'Citrine Securities', 250.00, 2),
(17, 'Aquamarine Assets', 250.00, 2),
(18, 'Peridot Portfolio', 300.00, 8),
(19, 'Tourmaline Trust', 100.00, 6),
(20, 'Moonstone Money', 150.00, 9);

-- Insert data into bondholders_bonds
INSERT INTO bondholders_bonds (bondholder_id, bond_id) VALUES
(1, 1),
(1, 2),
(1, 6),
(1, 8),
(1, 9),
(1, 13),
(1, 14),
(1, 16),
(1, 17),
(2, 4),
(2, 5),
(2, 7),
(2, 11),
(2, 15),
(2, 18),
(3, 3),
(3, 10),
(3, 12),
(3, 19),
(3, 20);


SELECT b1.name,ROUND(SUM(annual_coupon*coupons_remaining),2) AS total_cash_flow
FROM bondholders b1
JOIN bondholders_bonds b2 ON b1.id=b2.bondholder_id
JOIN bonds b3 ON b2.bond_id=b3.id
GROUP BY b1.name
HAVING SUM(b3.annual_coupon*b3.coupons_remaining) >10000.00;